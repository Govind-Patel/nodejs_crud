const express = require('express');
const conn =  require('./config');
const  app = express();

app.use(express.json());
app.get('/',(req,resp)=>{
    conn.query("select * from product",(err,result)=>{
        if(err)
        {
            resp.send('error');
        }else{
            resp.send(result);
        }
    });
});
app.post('/',(req,resp) => {
    const data = req.body;
    conn.query("INSERT into product set ?",data,(error,result,fields) =>{
        if(error) throw error;  
        resp.send(result);
    });
});

app.put('/:id',(req,resp) => {
    const data = [req.body.name,req.body.email,req.body.phone,req.params.id];
    conn.query("update product set name=?,email=?,phone=? where id = ?",data,(error,result,fields) =>{
        if(error) throw error;
        resp.send(result);
    });
});

app.delete('/:id',(req,resp)=>{
    conn.query("DELETE from product where id= " + req.params.id,(error,result) =>{
        if(error) throw error;
        resp.send(result);
    });
});

app.listen(5000);