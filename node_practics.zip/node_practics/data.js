const data = [
    {name:'Govinda',email:'gp@gmail.com'},
    {name:'Sahul',email:'sk@gmail.com'},
    {name:'Raj',email:'rj@gmail.com'},
    {name:'Manish',email:'mk@gmail.com'},
    {name:'Vishal',email:'vk@gmail.com'},
    {name:'Rahul',email:'rr@gmail.com'}
];
module.exports = data;